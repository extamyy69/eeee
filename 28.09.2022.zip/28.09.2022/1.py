y = int ( input ('введите курс доллар в рублях :'))
for i in range (1, 20): p = i * y
print (p)
