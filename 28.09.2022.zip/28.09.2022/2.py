k=p=n=int(input('n '))
while (5**k)>n: p=k; k-=1
print (p)
