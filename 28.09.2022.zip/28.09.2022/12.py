from math import *
f = int(input("Введите факториал числа n:"))
for n in range(1,f):
    if factorial(n) == f:
        print(n)
