a=int(input())
b=int(input())
if a<b:
    print(a,"Левее",b)
else:
    print(b,"Левее",a)
