lst = [-1,-2,-3,-5,-6,-7,-7,9,7,4,9]
count = 0
index = 0
while(lst[index]<0):
    count+=1
    index+=1
print(count)
