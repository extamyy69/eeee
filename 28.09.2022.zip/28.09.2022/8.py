n = input()
print(list(n).count(min(list(n))))
