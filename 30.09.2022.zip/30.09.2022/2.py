from math import *
x = int(input())
print(((x - 1) ** 2) - sin(2 * x))
