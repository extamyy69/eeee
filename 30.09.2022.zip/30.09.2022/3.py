from math import *
x, y = int(input()), int(input())

print(cos(y) + x - 1.5)
print(2 * y - sin(x - 0.5) - 1)
