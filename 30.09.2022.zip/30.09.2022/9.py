l = ['катя', 'маша', 'таня', 'саша']
l = [i.title() for i in l]
print(l)
