n = int(input())
print(n // 100 + n % 100 * 10)
