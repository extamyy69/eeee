l = str(input('Текст: '))
n = l.split(sep=' ') 
 
print(len(n))
