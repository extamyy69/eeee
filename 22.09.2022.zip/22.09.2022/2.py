n=input()
if n==n[2]+n[1]+n[0]:
    print("Палиндром")
else:
    print("Не палиндром")
    
