import math
x=int(input())
if x > 0:
    print(math.sin(x**2))
else:
    print(1 + 2 * math.sin(x)**2)
    
