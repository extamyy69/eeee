grades = [5, 4, 5, 3, 2, 5, 4, 3, 5, 5, 4, 2, 2, 3]
print(f'Средний балл: {sum(grades) / len(grades)}')
print(*grades, sep=';')
