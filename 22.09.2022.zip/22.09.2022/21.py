s = ['катя', 'маша', 'таня', 'саша']
s = [i.title() for i in s]
print(s)
