x=[]
n=int(input())
for i in range(1,n+1):
    y=str(i)
z=y + y
a.append(z)
print(x)
