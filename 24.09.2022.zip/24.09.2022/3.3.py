x = int(input())
y = int(input())
print(y//x)
print(y%x)
