a = int(input())
b = int(input())
print(1/2 * a * b)
