a = int(input())
b = int(input())
c = int(input())
print((a + b + c) // 2)
