n = input()
print(n[1] + n[0] + n[2])
