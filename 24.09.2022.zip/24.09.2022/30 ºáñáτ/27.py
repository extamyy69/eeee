n = input('? ')
a = str(n)[:-1]
d = str(n[-1])
print(d + a)
