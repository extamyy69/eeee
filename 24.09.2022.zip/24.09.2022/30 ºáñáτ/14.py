n = int(input('Введите число: '))
a = n % 10 % 2 == 0
b = n % 10 % 2 != 0
print('а)',a)
print('б)',b)
