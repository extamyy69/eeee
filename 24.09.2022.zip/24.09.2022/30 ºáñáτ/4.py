a=float(input('Первое число: '))
b=float(input('Второе число: '))
print(a if a>b else b)
