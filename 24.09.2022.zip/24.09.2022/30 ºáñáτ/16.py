kg = int(input())

print('тонн = ', kg//1000)
