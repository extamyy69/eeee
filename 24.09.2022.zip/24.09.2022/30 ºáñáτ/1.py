x=int(input())
if x > 4:
    print('II область')
else:
    print('I область')
