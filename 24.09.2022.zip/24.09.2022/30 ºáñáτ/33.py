a=int(input())
b=int(input())
if (a>100) and (b>100):
if ((a + b) mod 2=1):
if (a>0) of (b>0):
if (a mod 3=0) and (b mod 3=0) and (c mod 3=0):
if ((a<50) and (b>=50) and (c>=50)) or ((b<50) and (c>=50) and (a>=50)) or ((c<50) and (b>=50) and (a>=50)):
if (a<0) or (b<0) or (c<0):
