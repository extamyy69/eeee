n = int(input())
print('x = ', (n%12)+1)
