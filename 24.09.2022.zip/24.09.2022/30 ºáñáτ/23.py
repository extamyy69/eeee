n = input()
print(n[0] + n[2] + n[1])
