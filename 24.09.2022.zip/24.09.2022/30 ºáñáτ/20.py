n = input('Введите число ☺')
a = n[0]
print(n[1:] + a)
n=input('Введите число')
a = n[:2]
print(a + n[:2])
