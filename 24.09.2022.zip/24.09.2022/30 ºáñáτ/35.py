print('Рисунок a')
x,y = int(input('')), int(input(''))
if x < -1 and y < -2:
    print('Попадает')
else:
    print('Не попадает')
    print('Рисунок б')
y = int(input(''))
if 1<y>-3:
    print('Попадает')
else:
    print('Не попадает')
