b=int(input())
print(b%10*100+b%100//10*10+b//100)
