y=int(input())
if y>3:
    print('I область')
else:
    print('II область')
