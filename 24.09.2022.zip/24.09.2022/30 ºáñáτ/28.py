n = int(input())
print('x =', (n % 10)*100+(n // 10))
