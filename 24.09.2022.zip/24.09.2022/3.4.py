m=int(input())
print(m//60, m % 60)

