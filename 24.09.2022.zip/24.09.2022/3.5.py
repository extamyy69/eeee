Name = input('')
print('Hello,' + Name)
