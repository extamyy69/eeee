import numpy as np
Z = np.arange(12,44)
print(Z)