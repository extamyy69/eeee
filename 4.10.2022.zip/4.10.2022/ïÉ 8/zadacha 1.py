import numpy as np
Z = np.full(8, 3.2)
print(Z)