import numpy as np
Z = np.random.random((12,12))
Zmin, Zmax = Z.min(), Z.max()
print(Zmin, Zmax)