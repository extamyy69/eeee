import numpy as np
Z = np.dot(np.ones((4,2)), np.ones((2,5)))
print(Z)