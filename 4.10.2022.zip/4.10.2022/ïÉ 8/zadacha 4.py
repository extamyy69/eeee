import numpy as np
Z = np.random.random((3,3,2))
print(Z)