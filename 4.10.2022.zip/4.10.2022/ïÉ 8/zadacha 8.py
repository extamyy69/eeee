import numpy as np
Z = np.tile(np.array([[0,1],[1,0]]), (4,4))
print(Z)