import sys
print(set(map(str.rstrip, sys.stdin)))
