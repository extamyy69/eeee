a = [[i,10*i] for i in range(1,5)]
print(a)
b = sum(a,[])
print(b)
