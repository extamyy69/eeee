a, p = map(int, input("a, p = ").split())
lst = [a]
for i in range(1, 10):
    lst.append(a+i*p)
    print(*lst)
