s = list(input())
for i in reversed(s):
    print(i, end='')
